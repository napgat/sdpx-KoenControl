(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/[root-of-the-server]__04kpziu._.css","static/chunks/node_modules_1-hz3vc._.js","static/chunks/src_components_providers_tsx_1bw45og._.js"],
    source: "dynamic"
});
