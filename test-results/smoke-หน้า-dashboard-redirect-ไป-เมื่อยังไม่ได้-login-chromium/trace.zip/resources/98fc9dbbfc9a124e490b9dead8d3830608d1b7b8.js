(globalThis["TURBOPACK_CHUNK_LISTS"] || (globalThis["TURBOPACK_CHUNK_LISTS"] = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: ["static/chunks/src_0ajji58._.js","static/chunks/node_modules_lucide-react_dist_esm_0j0t2ip._.js"],
    source: "dynamic"
});
